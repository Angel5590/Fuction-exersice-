import UIKit
//
let multiple = {
    (val1 : Int, val2: Int) -> Int in
    return val1 * val2
}

let result = multiple(10, 200)
print (result)
